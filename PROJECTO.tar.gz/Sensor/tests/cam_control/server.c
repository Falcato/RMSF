#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <string.h>
#include <netdb.h>
#include <mysql/my_global.h>
#include <mysql/mysql.h>
#include <signal.h>
#include "cam_control1.c"

#define max(A,B) ((A)>=(B)?(A):(B))

void accao(char * comando){

	if(strcmp(comando,"PAN_LEFT")==0){ controlos('D');printf("Move Left\n");}
	else if(strcmp(comando,"PAN_RIGHT")==0){ controlos('C');printf("Move Right\n");}
	else if(strcmp(comando,"TILT_DOWN")==0){ controlos('B');printf("Move Down\n");}
	else if(strcmp(comando,"TILT_UP")==0){ controlos('A');printf("Move Up\n");}
	else if(strcmp(comando,"RESET_PAN")==0){ controlos('P');printf("Pan Reset\n");}
	else if(strcmp(comando,"RESET_TILT")==0){ controlos('T');printf("Tilt Reset\n");}
	else printf("Invalid\n");

}

void register_mysql(char *ip){
	
	MYSQL *con = mysql_init(NULL);

	if(con == NULL){
	  fprintf(stderr, "%s\n", mysql_error(con));
	  exit(1);
	}


	if(mysql_real_connect(con, "db.ist.utl.pt", "ist175757", "jcfs1855", "ist175757", 0, NULL, 0) == NULL){
	  fprintf(stderr, "%s\n", mysql_error(con));
	  mysql_close(con);
	  exit(1);
	} 

	char buff[128] = "INSERT INTO camera VALUES('";
	
	strcat(buff,ip);
	strcat(buff,"', '8081')");
	printf("----%s----\n", buff);
	
	if(mysql_query(con, buff) == 0){
	  printf("asas\n");
	  }
	mysql_close(con);
}

char * external_ip(char *buff){    
    FILE *in;
    extern FILE *popen();
    char buff2[512];	
	char cwd[1024];
	
	
	getcwd(cwd, sizeof(cwd));
	strcat(cwd, "/lol");

    if(!(in = popen(cwd, "r"))){
      exit(1);
    }

    while(fgets(buff2, sizeof(buff2)-1, in)!=NULL){
       printf("O IP externo é: %s", buff2);
    }
    strtok(buff2, "\n");
    strcpy(buff,buff2);
    pclose(in);
    return buff;
 }

void unregister_mysql(char *ip){
	
	MYSQL *con = mysql_init(NULL);

	if(con == NULL){
	  fprintf(stderr, "%s\n", mysql_error(con));
	  exit(1);
	}


	if(mysql_real_connect(con, "db.ist.utl.pt", "ist175757", "jcfs1855", "ist175757", 0, NULL, 0) == NULL){
	  fprintf(stderr, "%s\n", mysql_error(con));
	  mysql_close(con);
	  exit(1);
	} 

	char buff[128] = "DELETE FROM camera WHERE IP = '";
	
	strcat(buff,ip);
	strcat(buff,"'");
	printf("----%s----\n", buff);
	
	if(mysql_query(con, buff) == 0){
	  printf("asas\n");
	  }
	mysql_close(con);
}


volatile sig_atomic_t stop;

void inthand(int signum) {
	char IP[512]; 
	external_ip(IP);
	//UNREGISTER THE CAMERA FROM THE DATABSE
	unregister_mysql(IP);
	
	system("ps axf | grep motion | grep -v grep | awk '{print \"kill -9 \" $1}' | sh");
    exit(2);
}

int main(){
	
	//GET IP AND REGISTER IN THE DATABASE
	char IP[512]; 
	external_ip(IP);
	register_mysql(IP);
	
	
	system("nohup guvcview &");
	sleep(3);
	system("ps axf | grep guvcview | grep -v grep | awk '{print \"kill -9 \" $1}' | sh");
	sleep(3);
	system("nohup motion &");
	
	
	//RECIEVES SHUTDOWN SIGNAL 
	signal(SIGINT, inthand);
        
	int fd, newfd;
	struct sockaddr_in addr;
	int n;
	char buffer[128];
	

	
	if ((fd=socket(AF_INET, SOCK_STREAM, 0))==-1) exit(1);
	
	
	memset((void*)&addr, (int)'\0', sizeof(addr));
	addr.sin_family=AF_INET;
	addr.sin_addr.s_addr=htonl(INADDR_ANY);
	addr.sin_port=htons(9000);
	if(bind(fd, (struct sockaddr*)&addr, sizeof(addr))==-1)
		exit(1);
		
	if(listen(fd, 5)==-1) exit(1);
	
	//VARIAVEIS SELECT
	fd_set rfds;
	int maxfd;
	newfd=0;
	
	
	
	//LOOP PRINCIPAL
	while(1){

		FD_ZERO(&rfds);
		FD_SET(fd,&rfds);
		maxfd=max(maxfd,fd);
		
		if (newfd > 0){
			FD_SET(newfd,&rfds);
			maxfd=max(maxfd,newfd);
		}
		
		
		//SELECT
		if(select((maxfd+1),&rfds,(fd_set*)NULL,(fd_set*)NULL,(struct timeval*)NULL)==-1) exit(1);
		
		//RECEBEU LIGAÇAO
		if(FD_ISSET(fd, &rfds)){

			socklen_t addrlen=sizeof(addr);
		
			//ACEITA A NOVA LIGAÇAO
			newfd=accept(fd,(struct sockaddr*)&addr,&addrlen);
			//if(newfd==-1) exit(1);
			
			//LE DA NOVA LIGAÇAO
			bzero(buffer,128);
			n=read(newfd,buffer,128);
			buffer[n-1] = '\0';
			//if(n<=0) exit(1);
			printf("Recebi do listen:%s\n",buffer);
			
			accao(buffer);
		}
		//RECEBE DA LIGAÇAO JA EXISTENTE
		if(FD_ISSET(newfd, &rfds)){

			bzero(buffer,128);
			n=read(newfd,buffer,128);
			buffer[n-1] = '\0';
			if(n<=0){newfd=-1;printf("cliente foi embora\n");continue;}
			printf("Recebi do newfd:%s\n",buffer);
			
			accao(buffer);
		}
						
			
	}
	close(fd);
	exit(0);
}
