#include <stdio.h>
#include <sys/select.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <netdb.h>
#include <sys/socket.h>
#include <sys/types.h>
#include <sys/time.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <errno.h>
#include <ifaddrs.h>


int main(){
    FILE *in;
    extern FILE *popen();
    char buff[512];	
	char cwd[1024];
	
	
	getcwd(cwd, sizeof(cwd));
	strcat(cwd, "/lol");

    if(!(in = popen(cwd, "r"))){
      exit(1);
    }

    while(fgets(buff, sizeof(buff), in)!=NULL){
       printf("O IP externo é: %s", buff);
    }
    pclose(in);

	exit(0);
	}
